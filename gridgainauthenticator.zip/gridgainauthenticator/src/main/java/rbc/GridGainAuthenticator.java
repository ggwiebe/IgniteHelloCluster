package rbc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import org.apache.ignite.IgniteLogger;
import org.apache.ignite.internal.util.typedef.internal.U;
import org.apache.ignite.plugin.security.AuthenticationContext;
import org.apache.ignite.plugin.security.SecurityPermission;
import org.apache.ignite.plugin.security.SecurityPermissionSet;
import org.apache.ignite.plugin.security.SecurityPermissionSetBuilder;
import org.apache.ignite.plugin.security.SecuritySubject;
import org.apache.ignite.plugin.security.SecuritySubjectType;
import org.apache.ignite.resources.LoggerResource;
import org.gridgain.grid.security.AuthenticationValidator;
import org.gridgain.grid.security.Authenticator;
import org.gridgain.grid.security.SecuritySubjectAdapter;

import static javax.naming.Context.INITIAL_CONTEXT_FACTORY;
import static javax.naming.Context.PROVIDER_URL;
import static javax.naming.Context.SECURITY_AUTHENTICATION;
import static javax.naming.Context.SECURITY_CREDENTIALS;
import static javax.naming.Context.SECURITY_PRINCIPAL;
import static javax.naming.Context.SECURITY_PROTOCOL;

public class GridGainAuthenticator implements Authenticator, AuthenticationValidator {

    /** */
    private String ldapUrl;

    /** */
    private String ldapDomain;

    /** */
    private String ldapBindAuth;

    /** */
    private String ldapSearchLocation;

    /** */
    private String ldapSecuritySearchFilter;

    /** */
    private String ldapTrustStore;

    /** */
    private String ldapTrustStorePassword;

    /** */
    private Map<String, SecurityPermissionSet> ldapPermissions;

    /** */
    private boolean globalAuthentication;

    @LoggerResource(categoryClass = GridGainAuthenticator.class)
    private IgniteLogger log;

    private static SecuritySubject createSubject(AuthenticationContext authCtx,
        SecurityPermissionSet permissions) {
        return new SecuritySubjectAdapter(
            authCtx.subjectId(),
            authCtx.subjectType(),
            authCtx.credentials().getLogin(),
            authCtx.address(),
            permissions);
    }

    public void setLdapUrl(String ldapUrl) {
        this.ldapUrl = ldapUrl;
    }

    public void setLdapDomain(String ldapDomain) {
        this.ldapDomain = ldapDomain;
    }

    public void setLdapBindAuth(String ldapBindAuth) {
        this.ldapBindAuth = ldapBindAuth;
    }

    public void setLdapSearchLocation(String ldapSearchLocation) {
        this.ldapSearchLocation = ldapSearchLocation;
    }

    public void setLdapSecuritySearchFilter(String ldapSecuritySearchFilter) {
        this.ldapSecuritySearchFilter = ldapSecuritySearchFilter;
    }

    public void setLdapTrustStore(String ldapTrustStore) {
        this.ldapTrustStore = ldapTrustStore;
    }

    public void setLdapTrustStorePassword(String ldapTrustStorePassword) {
        this.ldapTrustStorePassword = ldapTrustStorePassword;
    }

    public void setLdapPermissions(Map<String, SecurityPermissionSet> ldapPermissions) {
        this.ldapPermissions = new HashMap<>();

        for (Map.Entry<String, SecurityPermissionSet> entry : ldapPermissions.entrySet())
            this.ldapPermissions.put(entry.getKey().toLowerCase(), entry.getValue());
    }

    public void setGlobalAuthentication(boolean globalAuthentication) {
        this.globalAuthentication = globalAuthentication;
    }

    @Override
    public Object validationToken() {
        Collection<Object> token = new ArrayList<>(3);

        token.add(ldapUrl);
        token.add(ldapTrustStorePassword);
        token.add(ldapPermissions);
        token.add(ldapBindAuth);

        return token;
    }

    @Override
    public SecuritySubject authenticate(AuthenticationContext authCtx) {
        if (authCtx.credentials() == null || authCtx.credentials().getLogin() == null)
            return null;

        String login = (String) authCtx.credentials().getLogin();
        String pwd = (String) authCtx.credentials().getPassword();

        if (pwd == null) {
            U.quietAndInfo(log,"Empty password provided: " + login);
            return null;
        }

        if (ldapUrl != null) {
            U.quietAndInfo(log,"Attempting authentication with LDAP: " + login);

            DirContext ldapCtx = getLdapContext(login, pwd);

            if (ldapCtx == null)
                return null;

            Collection<String> groups = getLdapGroups(login, ldapCtx);

            U.quietAndInfo(log,"Groups found: " + groups);

            SecurityPermissionSet permissions = getLdapPermissionSet(groups);

            U.quietAndInfo(log,"Permissions granted [login=" + login + ", permissions=" + permissions + ']');

            return createSubject(authCtx, permissions);
        } else {
            U.quietAndInfo(log,"LDAP authentication is disabled and will be skipped: " + login);
            return null;
        }
    }

    private DirContext getLdapContext(String login, String pwd) {
        DirContext ldapCtx;
        try {
            Hashtable<String, Object> ldapEnv = new Hashtable<>();

            ldapEnv.put(INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            ldapEnv.put(PROVIDER_URL, ldapUrl);
            //ldapEnv.put(SECURITY_AUTHENTICATION, "simple");
            ldapEnv.put(SECURITY_AUTHENTICATION, ldapBindAuth);
            //ldapEnv.put(SECURITY_AUTHENTICATION, "none");

            if ((ldapTrustStore != null)
                && (!ldapTrustStore.isEmpty())
                && (ldapTrustStorePassword != null)
                && (!ldapTrustStorePassword.isEmpty())) {

                U.quietAndInfo(log,"Using secured LDAP connection");
                ldapEnv.put(SECURITY_PROTOCOL, "ssl");
                System.setProperty("javax.net.ssl.trustStore", ldapTrustStore);
                System.setProperty("javax.net.ssl.trustStorePassword", ldapTrustStorePassword);
            }

            ldapCtx = new InitialDirContext(ldapEnv);

            ldapCtx.addToEnvironment(SECURITY_PRINCIPAL, login + "@" + ldapDomain);
            ldapCtx.addToEnvironment(SECURITY_CREDENTIALS, pwd);
       } catch (NamingException e) {
            log.error("Failed to authenticate with LDAP.", e);
            return null;
        }
        return ldapCtx;
    }

    private Collection<String> getLdapGroups(String login, DirContext ldapCtx) {
        Collection<String> groups = new ArrayList<>();
        try {
            //String filter = "uid=glenn";
            String filter = ldapSecuritySearchFilter.replaceAll("\\{USERNAME}", login);

            SearchControls controls = new SearchControls();

            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            //controls.setReturningAttributes(new String[]{ "memberOf" });
            controls.setReturningAttributes(new String[]{ "employeeType" });

            NamingEnumeration<SearchResult> res = ldapCtx.search(ldapSearchLocation, filter, controls);

            try {
                if (res.hasMore()) {
                    SearchResult entry = res.next();

                    U.quietAndInfo(log,"LDAP entry found: " + entry);

                    //Attribute memberOf = entry.getAttributes().get("memberOf");
                    Attribute memberOf = entry.getAttributes().get("employeeType");

                    if (memberOf != null) {
                        NamingEnumeration<?> vals = memberOf.getAll();

                        try {
                            while (vals.hasMore())
                                groups.add((String) vals.next());
                        } finally {
                            vals.close();
                        }
                    }
                } else {
                    U.quietAndInfo(log,"LDAP returned empty search result.");
                    return Collections.emptyList();
                }
            } finally {
                res.close();
            }
        } catch (NamingException e) {
            log.error("Failed to search LDAP.", e);
            return Collections.emptyList();
        }
        return groups;
    }

    private SecurityPermissionSet getLdapPermissionSet(Collection<String> groups) {
        SecurityPermissionSetBuilder builder = new SecurityPermissionSetBuilder();

        if (ldapPermissions != null) {
            builder.defaultAllowAll(false);

            for (String group : groups) {
                group = group.toLowerCase();

                SecurityPermissionSet grpPerms = ldapPermissions.get(group);

                if (grpPerms != null) {
                    Collection<SecurityPermission> grpSysPerms = grpPerms.systemPermissions();
                    if (grpSysPerms != null) {
                        for (SecurityPermission grpSysPerm : grpSysPerms)
                            builder.appendSystemPermissions(grpSysPerm);
                    }

                    if (grpPerms.defaultAllowAll())
                        builder.defaultAllowAll(true);
                }
            }
        }

        return builder.build();
    }

    @Override
    public boolean isGlobalNodeAuthentication() {
        return globalAuthentication;
    }

    @Override
    public boolean supported(SecuritySubjectType subjType) {
        return true;
    }
}
